<?php

include_once QODE_CORE_SHORTCODES_PATH . '/image-with-text/functions.php';
include_once QODE_CORE_SHORTCODES_PATH . '/image-with-text/image-with-text.php';