<?php

include_once QODE_CORE_ABS_PATH . '/widgets/sidearea-opener/functions.php';
include_once QODE_CORE_ABS_PATH . '/widgets/sidearea-opener/side-area-opener.php';