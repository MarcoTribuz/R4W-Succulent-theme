<?php

if ( qodef_core_is_woocommerce_installed() ):
	include_once QODE_CORE_ABS_PATH . '/widgets/woocommerce-dropdown-cart/functions.php';
	include_once QODE_CORE_ABS_PATH . '/widgets/woocommerce-dropdown-cart/woocommerce-dropdown-cart.php';
endif;