<?php

include_once QODE_CORE_CPT_PATH . '/team/team-register.php';
include_once QODE_CORE_CPT_PATH . '/team/helper-functions.php';