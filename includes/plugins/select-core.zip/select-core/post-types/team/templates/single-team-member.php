<?php

get_header();

succulents_qodef_get_title();

do_action('succulents_qodef_before_main_content');

qodef_core_get_single_team();

get_footer();